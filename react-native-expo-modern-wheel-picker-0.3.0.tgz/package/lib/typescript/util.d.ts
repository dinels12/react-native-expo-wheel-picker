export declare const setAlphaColor: (color: string, opacity?: number) => string;
export declare const adaptiveColor: (backgroundColor: string) => string;
//# sourceMappingURL=util.d.ts.map