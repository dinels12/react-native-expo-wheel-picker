import React, { PureComponent } from "react";
import { FlatList } from "react-native";
import type { IViuPickerProps, IViuPickerState } from "./types";
declare class WheelPickerExpo extends PureComponent<IViuPickerProps, IViuPickerState> {
    static defaultProps: {
        items: never[];
        backgroundColor: string;
        width: number;
        haptics: boolean;
    };
    flatListRef: React.RefObject<FlatList<any> | null>;
    backgroundColor: string;
    state: {
        selectedIndex: number;
        itemHeight: number;
        listHeight: number;
        data: never[];
    };
    userTouch: boolean;
    componentDidUpdate(prevProps: IViuPickerProps): void;
    componentDidMount(): void;
    get gradientColor(): string;
    get gradientContainerStyle(): ({
        position: "absolute";
        width: "100%";
    } | {
        height: number;
        borderColor: string | undefined;
    })[];
    handleOnSelect(index: number): void;
    handleOnPressItem: (index: number) => void;
    setData(): void;
    render(): React.JSX.Element | undefined;
}
export default WheelPickerExpo;
//# sourceMappingURL=index.d.ts.map